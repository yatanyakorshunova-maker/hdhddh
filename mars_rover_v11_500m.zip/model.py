from __future__ import annotations

import math

import torch
from torch import nn
from torch.nn import functional as F

X = 0
Y = 1
VX = 2
VY = 3
ANGLE = 4
ANGULAR_VEL = 5
ENERGY = 6
LIDAR_LANDING = 7

TERRAIN_HEIGHT_0 = 32
TERRAIN_SLOPE_0 = 56
BIOME_0 = 80
DRIVE_GEAR = 104
DRIVE_LOAD = 105
GEAR_MUL = 106
RPM = 107
DRIVE_MODE = 108
ENGINE_STALLED = 109
CLUTCH = 110
ENGINE_TEMP = 111
HEATER = 112
OVERHEATED = 113
COLD_LOCKED = 114
SOLAR_DEPLOY = 115
CHARGING = 116
SOLAR_RATE = 117
LIDAR_ACTIVE = 118
LIDAR_COOLDOWN = 119
PREVIOUS_RAW_ACTION = 120
LAST_REWARD = 121

IMU_0 = 122
CONTACT_0 = 126
WHEEL_ANGULAR_0 = 129
SUSPENSION_0 = 137

CLIMB = 145
PROPELLER = 146
JUMP_COOLDOWN = 147
RECOVERY = 148
ENERGY_2 = 149
FUEL_RATE = 150
AIRBORNE = 151
PROP_DEPLOY = 155
JUMP_CHARGE = 156
ROOF_PISTON = 157
ENERGY_COST = 158
BALLAST_AIR = 159

A_NONE = 0
A_GAS = 1
A_BRAKE = 2
A_REVERSE = 3
A_UPSHIFT = 4
A_GAS_UPSHIFT = 5
A_TILT_UPSHIFT_L = 6
A_TILT_UPSHIFT_R = 7
A_DOWNSHIFT = 8
A_IGNITION = 9
A_GAS_TILT_L = 10
A_GAS_TILT_R = 11
A_LIDAR = 12
A_TOGGLE_DRIVE = 13
A_CHARGE = 14
A_JUMP = 15
A_CLIMB = 16
A_PROPELLER = 17
A_ROOF_PISTON = 18
A_JUMP_FRONT = 19
A_JUMP_REAR = 20
A_ROOF_FRONT = 21
A_ROOF_REAR = 22
A_BALLAST_BLOW = 23
A_BALLAST_FLOOD = 24
A_THRUSTER = 25
A_GAS_THRUSTER = 26
A_HEATER = 27
A_GAS_HEATER = 28
A_GAS_HEATER_TILT_L = 29
A_GAS_HEATER_TILT_R = 30


class Policy(nn.Module):
    """Recurrent PPO policy with a compact, exportable mechanics prior.

    The previous version used a large collection of boolean masks as a
    training-only prior.  That helped training, but the official ONNX export
    deliberately omitted it, so the evaluator saw a different policy than the
    one that was trained.  Here the useful mechanical hints are compressed into
    a small learned linear head.  It is present both during PPO and in ONNX.
    """

    def __init__(self, obs_dim: int, action_dim: int, hidden_size: int):
        super().__init__()
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        self.hidden_size = hidden_size

        input_dim = obs_dim + action_dim + 3
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_size),
            nn.Tanh(),
        )
        self.memory = nn.GRUCell(hidden_size, hidden_size)
        self.actor = nn.Linear(hidden_size, action_dim)
        self.critic = nn.Linear(hidden_size, 1)

        # Small exportable mechanics head.  The feature vector intentionally
        # uses already-normalized observations and a few cheap derived signals.
        self.mechanics_head = nn.Linear(22, action_dim, bias=True)
        # Frozen export-safe safety controller. It is trained neither by PPO nor
        # by the optimizer; it supplies a stable attitude/jump prior in every
        # environment while the learned policy handles the remaining choices.
        self.safety_head = nn.Linear(22, action_dim, bias=False)
        self._init_weights()

    def _init_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.orthogonal_(module.weight, math.sqrt(2))
                nn.init.zeros_(module.bias)

        # Main policy starts with a strong forward-driving preference.
        with torch.no_grad():
            self.actor.bias.fill_(-0.35)
            self.actor.bias[A_NONE] = -1.5
            self.actor.bias[A_GAS] = 1.5

        nn.init.orthogonal_(self.actor.weight, 0.01)
        nn.init.orthogonal_(self.critic.weight, 1.0)
        nn.init.zeros_(self.critic.bias)

        # Start the compact mechanics head with a useful hand-designed prior.
        # PPO can change every coefficient during training, and because the head
        # is part of the exported graph the evaluator sees the same prior.
        with torch.no_grad():
            self.mechanics_head.weight.zero_()
            self.mechanics_head.bias.zero_()
            w = self.mechanics_head.weight
            b = self.mechanics_head.bias

            # Feature 0 is speed, then attitude/energy/terrain/drive signals.
            # No ones_like/ConstantOfShape is used: the export validator only
            # permits a small fixed ONNX operator set. A constant gas preference
            # is represented by the bias instead.
            b[A_GAS] += 2.25

            # 0 speed, 1 abs angle, 2 signed angle, 3 abs angular velocity
            # 4 energy, 5 rpm, 6 engine temp, 7 cold lock, 8 charging
            # 9 airborne, 10 climb, 11 propeller, 12 jump charge
            # 13 recovery, 14 slope_max, 15 step_max, 16 drive load
            # 17 wheel slip, 18 low_rpm_speed, 19 high_rpm
            # 20 low_energy_stationary, 21 severe_attitude
            w[A_GAS, 0] += 0.45
            w[A_GAS, 4] += 0.20
            w[A_GAS, 17] += 0.55
            w[A_GAS, 16] += 0.25

            w[A_GAS_UPSHIFT, 19] += 3.2
            w[A_DOWNSHIFT, 18] += 2.4

            w[A_HEATER, 7] += 6.0
            w[A_GAS_HEATER, 7] += 3.0
            w[A_IGNITION, 18] += 0.8

            w[A_CLIMB, 14] += 2.2
            w[A_JUMP, 15] += 3.2
            w[A_JUMP, 21] += 1.5
            w[A_JUMP, 12] += 0.9
            w[A_JUMP_FRONT, 15] += 0.7
            w[A_JUMP_REAR, 15] += 0.7

            w[A_LIDAR, 9] += 0.8
            w[A_LIDAR, 15] += 0.35
            w[A_THRUSTER, 9] += 3.0
            w[A_GAS_THRUSTER, 9] += 1.8

            w[A_CHARGE, 20] += 3.0
            w[A_CHARGE, 8] += 1.0

            # Keep the rover moving in difficult traction regimes.
            # Strong PD-like attitude stabilizer. Positive angle/angular velocity means
            # nose-up rotation; GAS_TILT_R applies the negative body torque.
            w[A_GAS_TILT_R, 2] += 2.8
            w[A_GAS_TILT_R, 3] += 2.0
            w[A_GAS_TILT_L, 2] -= 2.8
            w[A_GAS_TILT_L, 3] -= 2.0
            w[A_JUMP_REAR, 2] += 1.2
            w[A_JUMP_FRONT, 2] -= 1.2
            w[A_ROOF_FRONT, 2] += 0.6
            w[A_ROOF_REAR, 2] -= 0.6

        # Fixed residual controller: feature 2 is signed body angle, feature 3
        # is angular speed, feature 15 is the largest visible terrain step, and
        # feature 21 is severe attitude. Positive angle means the controller
        # prefers GAS_TILT_R (negative body torque); negative angle prefers
        # GAS_TILT_L.
        with torch.no_grad():
            self.safety_head.weight.zero_()
            sw = self.safety_head.weight
            sw[A_GAS, 0] = 0.9
            sw[A_GAS, 17] = 0.5
            sw[A_GAS_TILT_R, 2] = 3.6
            sw[A_GAS_TILT_R, 3] = 2.2
            sw[A_GAS_TILT_L, 2] = -3.6
            sw[A_GAS_TILT_L, 3] = -2.2
            sw[A_JUMP, 15] = 2.2
            sw[A_JUMP, 21] = 1.0
            sw[A_JUMP_REAR, 2] = 0.9
            sw[A_JUMP_FRONT, 2] = -0.9
            sw[A_LIDAR, 15] = 0.25
        self.safety_head.weight.requires_grad_(False)

    def initial(self, batch: int, device: torch.device) -> torch.Tensor:
        return torch.zeros(batch, self.hidden_size, device=device)

    @staticmethod
    def _mechanics_features(observation: torch.Tensor) -> torch.Tensor:
        """Build 22 cheap, normalized, export-friendly mechanics features."""
        speed = observation[:, VX].abs()
        angle = observation[:, ANGLE]
        abs_angle = angle.abs()
        angular_speed = observation[:, ANGULAR_VEL].abs()
        energy = observation[:, ENERGY].clamp(0.0, 1.2)
        rpm = observation[:, RPM].clamp(0.0, 1.5)
        temp = observation[:, ENGINE_TEMP].clamp(-1.0, 2.0)
        cold = observation[:, COLD_LOCKED].clamp(0.0, 1.0)
        charging = observation[:, CHARGING].clamp(0.0, 1.0)
        airborne = observation[:, AIRBORNE].clamp(0.0, 1.0)
        climb = observation[:, CLIMB].clamp(0.0, 1.0)
        propeller = observation[:, PROPELLER].clamp(0.0, 1.0)
        jump_charge = observation[:, JUMP_CHARGE].clamp(0.0, 1.0)
        recovery = observation[:, RECOVERY].clamp(0.0, 1.0)

        terrain_slope = observation[:, TERRAIN_SLOPE_0:TERRAIN_SLOPE_0 + 24]
        terrain_height = observation[:, TERRAIN_HEIGHT_0:TERRAIN_HEIGHT_0 + 24]
        slope_max = terrain_slope.abs().amax(dim=1)
        step_max = terrain_height.abs().amax(dim=1)

        drive_load = observation[:, DRIVE_LOAD].clamp(0.0, 2.0)
        slip = observation[:, 9:12].abs().mean(dim=1)

        low_rpm_speed = torch.relu(0.22 - rpm) * (0.5 + speed)
        high_rpm = torch.relu(rpm - 0.76)
        low_energy_stationary = torch.relu(0.24 - energy) * torch.relu(0.08 - speed)
        severe_attitude = torch.relu(abs_angle - 0.65) + torch.relu(angular_speed - 0.25)

        return torch.stack(
            (
                speed,
                abs_angle,
                angle,
                angular_speed,
                energy,
                rpm,
                temp,
                cold,
                charging,
                airborne,
                climb,
                propeller,
                jump_charge,
                recovery,
                slope_max,
                step_max,
                drive_load,
                slip,
                low_rpm_speed,
                high_rpm,
                low_energy_stationary,
                severe_attitude,
            ),
            dim=1,
        )

    def _features(self, observation, previous_action, previous_reward, previous_done, trial_progress):
        action = F.one_hot(previous_action.long(), self.action_dim).float()
        reward = torch.tanh(previous_reward.unsqueeze(-1) / 10.0)
        done = previous_done.float().unsqueeze(-1)
        progress = trial_progress.float().unsqueeze(-1)
        return torch.cat((observation, action, reward, done, progress), dim=-1)

    def step(
        self,
        observation,
        previous_action,
        previous_reward,
        previous_done,
        trial_progress,
        trial_start,
        memory,
    ):
        # NOTE: nan_to_num() was tried here as a defensive guard but it
        # traces to an ONNX IsNaN node, which the platform's exporter
        # explicitly rejects ("Операция ONNX IsNaN не разрешена."). step()
        # is exactly the function that gets exported, so only ops from the
        # platform's allowed set may appear here. Clip (clamp) is a standard,
        # universally-supported op and is kept as a cheap safeguard against
        # runaway magnitudes; it does not remove actual NaNs, but bounding
        # values this way also makes it much less likely for a single
        # extreme-but-finite physics glitch to blow up recurrent state or the
        # value target in the first place.
        observation = observation.clamp(-50.0, 50.0)

        reset_mask = trial_start.float().unsqueeze(-1)
        memory = memory * (1.0 - reset_mask)
        features = self._features(
            observation, previous_action, previous_reward, previous_done, trial_progress
        )
        encoded = self.encoder(features)
        memory = self.memory(encoded, memory)
        memory = memory.clamp(-10.0, 10.0)

        logits = self.actor(memory)
        mechanics = self._mechanics_features(observation)
        logits = logits + self.mechanics_head(mechanics)

        # Fixed safety residual is present in PPO and in the exported ONNX graph.
        logits = logits + self.safety_head(mechanics)
        # +-20 logits already gives a >10^8:1 probability ratio between the
        # best and worst action, so this never meaningfully constrains a
        # healthy policy; it only stops a runaway from reaching Inf in the
        # downstream softmax/log-prob computation.
        logits = logits.clamp(-20.0, 20.0)

        value = self.critic(memory).squeeze(-1)
        return logits, value, memory

    def sequence(
        self,
        observation,
        previous_action,
        previous_reward,
        previous_done,
        trial_progress,
        trial_start,
        memory,
    ):
        logits = []
        values = []
        for i in range(len(observation)):
            current_logits, current_value, memory = self.step(
                observation[i],
                previous_action[i],
                previous_reward[i],
                previous_done[i],
                trial_progress[i],
                trial_start[i],
                memory,
            )
            logits.append(current_logits)
            values.append(current_value)
        return torch.stack(logits), torch.stack(values)
