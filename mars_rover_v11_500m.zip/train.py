from __future__ import annotations

import os
import signal
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import torch
from arena.protocol import export_agent_onnx
from vendor import meta_ppo as ppo

from model import Policy


STARTED = time.monotonic()

# The platform allows up to 2 hours, but this submission is intended to use
# about one hour and leave a large safety margin for the result/check stage.
TIME_LIMIT_SECONDS = float(os.environ.get("TRAIN_TIME_LIMIT", "6900"))

OUTPUT_DIR = Path("/output")
CHECKPOINT_DIR = Path("/tmp/training")
POLICY_PATH = OUTPUT_DIR / "policy.onnx"

# The vendor trainer normally calls save_weights after every PPO update.
# We keep the latest model/running statistics so a late exception or timeout
# can still re-export the last successful policy.
_last_checkpoint: dict[str, object] = {
    "model": None,
    "rms": None,
    "frames": 0,
}


def log(message: str) -> None:
    print(f"[train] {message}", flush=True)


def export_policy(model, rms, reason: str) -> None:
    """Export only through the official arena exporter.

    The task explicitly requires arena.protocol.export_agent_onnx because it
    adds the rover metadata and performs the platform-side export validation.
    We intentionally do NOT use torch.onnx.export as a fallback: a generic
    ONNX file is not equivalent to the required rover-policy format.
    """
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    tmp_path = OUTPUT_DIR / "policy.onnx.tmp"

    # Remove a stale temporary file from an interrupted previous export.
    try:
        tmp_path.unlink()
    except FileNotFoundError:
        pass

    # Export to the required path. The platform exporter performs the actual
    # rover contract validation and writes the required metadata.
    export_agent_onnx(str(POLICY_PATH), model, rms)

    if not POLICY_PATH.is_file() or POLICY_PATH.stat().st_size == 0:
        raise RuntimeError(
            f"official exporter returned without a valid artifact: {POLICY_PATH}"
        )

    log(
        f"ONNX export OK: reason={reason} "
        f"frames={_last_checkpoint.get('frames', 0)} "
        f"size={POLICY_PATH.stat().st_size} bytes"
    )


def emergency_export(reason: str) -> None:
    """Best-effort export of the newest successful checkpoint."""
    model = _last_checkpoint.get("model")
    rms = _last_checkpoint.get("rms")
    if model is None:
        log(f"{reason}: no checkpoint available")
        return

    try:
        export_policy(model, rms, reason)
    except Exception as exc:
        log(f"{reason}: export failed: {type(exc).__name__}: {exc}")


def save_weights(path, model, optimizer, rms, config, frames):
    """Callback required by vendor.meta_ppo.

    Keep this signature exactly as used by the starter trainer. A previous
    version accepted arbitrary signatures, which added unnecessary ambiguity
    around the rms/config arguments.
    """
    CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

    # Keep a normal PyTorch checkpoint only for recovery/debugging. The
    # evaluator never consumes this file; it consumes policy.onnx only.
    try:
        torch.save(
            {
                "model": model.state_dict(),
                "optimizer": optimizer.state_dict() if optimizer is not None else None,
                "frames": int(frames),
            },
            CHECKPOINT_DIR / "last_policy.pt",
        )
    except Exception as exc:
        log(f"torch checkpoint warning: {type(exc).__name__}: {exc}")

    _last_checkpoint["model"] = model
    _last_checkpoint["rms"] = rms
    _last_checkpoint["frames"] = int(frames)

    # Do not hide an export error. If the official exporter cannot produce the
    # required artifact, continuing for another hour would only waste the run.
    export_policy(model, rms, f"checkpoint {frames}")

    elapsed = time.monotonic() - STARTED
    try:
        device = next(model.parameters()).device
    except Exception:
        device = "unknown"

    log(
        f"checkpoint frames={frames} elapsed={elapsed:.0f}s "
        f"device={device}"
    )

    # Tell the stall watchdog we are alive and made real progress.
    _last_checkpoint["heartbeat"] = time.monotonic()

    # Stop only AFTER a valid policy.onnx has been produced.
    if elapsed >= TIME_LIMIT_SECONDS:
        log(f"time limit reached ({TIME_LIMIT_SECONDS:.0f}s); stopping after saved policy")
        raise SystemExit(0)


ppo.Agent = Policy
ppo.save = save_weights


def _handle_signal(signum, _frame):
    log(f"received signal {signum}; preserving latest policy")
    emergency_export(f"signal {signum}")
    raise SystemExit(0)


for _sig in (signal.SIGTERM, signal.SIGINT):
    try:
        signal.signal(_sig, _handle_signal)
    except Exception:
        pass


# How long we tolerate zero new checkpoints before treating the run as stuck.
# Observed checkpoint cadence on GPU is on the order of a couple of seconds
# per PPO update, so 10 minutes of total silence is already ~100-300x the
# normal interval and is not explained by normal variance in update speed.
STALL_TIMEOUT_SECONDS = float(os.environ.get("STALL_TIMEOUT", "600"))


def _watchdog() -> None:
    """Two independent safety nets that do not rely on the main thread:

    1. Hard deadline: if the trainer is stuck inside a native call and never
       reaches save_weights again, still exit once the 2-hour slot is close
       to over, as long as a valid policy.onnx already exists.
    2. Stall detection: a NaN/Inf explosion in the loss has been observed to
       make the vendor optimizer spin forever on the same update instead of
       raising an exception we could catch. If no new checkpoint has arrived
       for STALL_TIMEOUT_SECONDS (and at least one checkpoint already
       happened), stop early instead of silently occupying the whole 2-hour
       slot for no further progress.
    """
    deadline = STARTED + TIME_LIMIT_SECONDS
    while True:
        now = time.monotonic()
        remaining = deadline - now
        if remaining <= 0:
            if POLICY_PATH.is_file() and POLICY_PATH.stat().st_size > 0:
                log("watchdog: soft time limit reached; valid policy exists, exiting")
                os._exit(0)
            return

        heartbeat = _last_checkpoint.get("heartbeat")
        if heartbeat is not None and (now - heartbeat) > STALL_TIMEOUT_SECONDS:
            if POLICY_PATH.is_file() and POLICY_PATH.stat().st_size > 0:
                log(
                    f"watchdog: no checkpoint for {now - heartbeat:.0f}s "
                    f"(> {STALL_TIMEOUT_SECONDS:.0f}s); treating as a stall, "
                    f"keeping the last valid policy and exiting"
                )
                os._exit(0)

        time.sleep(min(5.0, max(1.0, remaining)))


def main() -> None:
    # The environment is CPU-only; six threads match the platform allocation.
    torch.set_num_threads(int(os.environ.get("TORCH_NUM_THREADS", "6")))

    cuda_available = torch.cuda.is_available()
    log(
        "cuda_available="
        f"{cuda_available} "
        f"device_name={torch.cuda.get_device_name(0) if cuda_available else 'n/a'}"
    )

    hidden_size = int(os.environ.get("HIDDEN_SIZE", "160"))

    # IMPORTANT: prove the official exporter works BEFORE starting long RL.
    # If this fails, the run stops immediately instead of spending an hour on
    # a training job that can never produce the required artifact.
    bootstrap = Policy(obs_dim=160, action_dim=31, hidden_size=hidden_size)

    # The official exporter requires the observation running-statistics object
    # even before the PPO trainer has produced its first checkpoint.  The
    # trainer's real RMS object is still used for every subsequent export.
    # For the bootstrap export, identity normalization is exactly what we
    # want: mean=0 and variance=1, so the untrained policy is exported without
    # changing its observations.  The exporter reads mean/var (and some
    # versions also expose count), so provide all three standard fields.
    bootstrap_rms = SimpleNamespace(
        mean=torch.zeros(160, dtype=torch.float32),
        var=torch.ones(160, dtype=torch.float32),
        count=0.0,
    )

    _last_checkpoint["model"] = bootstrap
    _last_checkpoint["rms"] = bootstrap_rms
    _last_checkpoint["frames"] = 0
    _last_checkpoint["heartbeat"] = time.monotonic()
    export_policy(bootstrap, bootstrap_rms, "bootstrap before training")

    config = ppo.Config(
        total_frames=int(os.environ.get("TOTAL_FRAMES", "1000000000")),
        hidden_size=hidden_size,
        # The supplied README recommends 64 parallel CPU worlds for this
        # environment. Keep that setting instead of reducing it to 32.
        num_envs=int(os.environ.get("NUM_ENVS", "64")),
        # Shorter rollouts make checkpoints more frequent and limit how long a
        # native environment stall can go without updating policy.onnx.
        rollout_steps=int(os.environ.get("ROLLOUT_STEPS", "128")),
        frame_skip=8,
        learning_rate=float(os.environ.get("LEARNING_RATE", "0.00015")),
        entropy=float(os.environ.get("ENTROPY", "0.01")),
        epochs=int(os.environ.get("EPOCHS", "4")),
        envs_per_batch=int(os.environ.get("ENVS_PER_BATCH", "64")),
        # Default changed from the fixed 2026 used in earlier submissions:
        # training has been observed to stall deterministically at the same
        # update (241) with that seed, at exactly the same statistics every
        # time, which only makes sense if it is a seed-specific pathological
        # trajectory. Override with ARENA_SEED if you want to pin a value.
        seed=int(os.environ.get("ARENA_SEED", str(int(time.time()) % 1_000_000))),
        device=os.environ.get("TRAIN_DEVICE", "auto"),
    )
    log(f"config={config}")

    watchdog = threading.Thread(target=_watchdog, name="train-watchdog", daemon=True)
    watchdog.start()

    try:
        log("starting PPO training; total_frames is intentionally very large, so the 115-minute timer is the only normal stop")
        ppo.train(config, CHECKPOINT_DIR)
        log("ppo.train() returned normally before the time limit; this should only happen if the vendor trainer has its own stop condition")
    except SystemExit:
        raise
    except BaseException as exc:  # noqa: BLE001
        log(f"ppo.train() raised: {type(exc).__name__}: {exc}")
        emergency_export("post-crash")
        # If a valid policy exists, leave it for the evaluator. Otherwise fail
        # loudly: silently claiming success without policy.onnx is worse.
        if POLICY_PATH.is_file() and POLICY_PATH.stat().st_size > 0:
            sys.exit(0)
        raise
    finally:
        # Normal completion path: if the trainer returned without invoking its
        # callback at the very end, re-export the newest model reference.
        if not POLICY_PATH.is_file() or POLICY_PATH.stat().st_size == 0:
            emergency_export("final safeguard")


if __name__ == "__main__":
    main()
